from django.contrib.auth.decorators import login_required
from django.forms import modelform_factory
from django.shortcuts import render, redirect
from pogotowieapp.models import *

forma = modelform_factory(Zgloszenia,exclude=[])
def delete(request,id):
    delete = Zgloszenia.objects.get(pk=id)
    delete.delete()
    return redirect('pogotowie')
@login_required
def edytuj(request,id):
    edit = Zgloszenia.objects.get(pk=id)
    form = forma(request.POST or None, instance=edit)
    if form.is_valid():
        form.save()
        return redirect('pogotowie')
    return render(request,'edit.html',{'form':form})

def pogotowie(request):
    zgl = Zgloszenia.objects.all()
    if request.method == 'POST':
        form = forma(request.POST)
        if form.is_valid():
            form.save()
            return redirect("/")
    else:
        form = forma()

    return render(request, 'pogotowie.html',{'zgl':zgl,'form':form})