from django.shortcuts import render
from .forms import Licz
from farbyapp.models import Farby
import math

def welcome(request):
    farby = Farby.objects.all()
    liczenie = Licz()

    if request.method == 'POST':
        pole = request.POST['pole']
        suma1 = int(pole)/4
        suma = math.ceil(suma1)
        context = {
            'farby': farby,
            'suma':suma,
            'liczenie':liczenie
        }
        return render(request, 'welcome.html', context)

    return render(request, 'welcome.html', {"farby":farby,"liczenie":liczenie})