from django import forms

class Licz(forms.Form):
    pole = forms.IntegerField()
    def __init__(self, *args, **kwargs):
        super(Licz, self).__init__(*args, **kwargs)
        self.fields['pole'].label = "Powierzchnia malowania m2 "