from django.contrib import admin
from farbyapp.models import Farby, Malowanie
admin.site.register(Farby)
admin.site.register(Malowanie)
