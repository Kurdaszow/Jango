from django.db import models

# Create your models here.
class Farby(models.Model):
    kolor = models.CharField(max_length=100)
    cena = models.IntegerField()
    pojemnosc = models.IntegerField()
    def __str__(self):
        return f"{self.kolor}"

class Malowanie(models.Model):
    id_malowanie = models.IntegerField()
    id_sciany = models.IntegerField()
    liczba_puszek = models.IntegerField()
    id_farby = models.ForeignKey(Farby,on_delete=models.CASCADE)
    def __str__(self):
        return f"{self.id_malowanie}"

